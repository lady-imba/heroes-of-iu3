import Castle.Castle;
import UI.GameMap;
import Hero.Hero;
import Player.*;
import Unit.Unit;

import java.util.*;


public class Main {
    public static void main(String[] args) {
        int mapHeight = 10;
        int mapWidth = 10;
        int maxMovementRange = (int) Math.round(Math.sqrt(Math.pow(mapWidth-3, 2) + Math.pow(mapHeight-3, 2)) / 2);

        HumanPlayer humanPlayer = new HumanPlayer(new Hero(1, 1, 100, "Warrior"), "&", false, "Biba");
        ComputerPlayer computer = new ComputerPlayer(new Hero(mapWidth - 2, mapHeight - 2, maxMovementRange, "Warrior"),"$",true, "Boba");

        humanPlayer.getActiveHero().addUnit(new Unit("Копейщик", 10, 2, 2, 2));
        humanPlayer.getActiveHero().addUnit(new Unit("Копейщик", 10, 2, 2, 2));
        computer.getActiveHero().addUnit(new Unit("Копейщик", 10, 2, 2, 2));
        computer.getActiveHero().addUnit(new Unit("Копейщик", 10, 2, 2, 2));

        Player[] players = new Player[]{humanPlayer, computer};

        Castle playerCastle = new Castle(humanPlayer, 0, 0);
        Castle computerCastle = new Castle(computer, mapWidth - 1, mapHeight - 1);
        humanPlayer.setCastle(playerCastle);
        computer.setCastle(computerCastle);

        GameMap gameMap = new GameMap(mapHeight, mapWidth, new Castle[]{playerCastle, computerCastle}, humanPlayer, computer);

        int turns = 100;

        while (turns > 0) {
            gameMap.getOasis().resetOasis();
            for (Castle castle : new Castle[]{playerCastle, computerCastle}) {
                castle.processInvasion();
            }
            for (Player p : players) {
                p.getActiveHero().resetMovementRange();
                System.out.printf("Герой игрока %s восстановил энергию: %d/%d%n",
                        p.getName(),
                        p.getActiveHero().getMovementRange(),
                        p.getActiveHero().getMaxMovementRange());
            }
            for (int i = 0; i < players.length; i++) {
                ArrayList<Hero> restHeroes = new ArrayList<>();
                for (int j = 0; j < players.length; j++) {
                    if (i != j) {
                        restHeroes.add(players[j].getActiveHero());
                    }
                }
                gameMap.Display(players[i].getActiveHero(), restHeroes, humanPlayer,computer);

                if (i == 0) {
                    humanPlayer.moveHero(players[i].getActiveHero(), restHeroes, computer, gameMap);
                } else {
                    computer.computerMove(players[i].getActiveHero(), players[0].getActiveHero(), playerCastle, humanPlayer, gameMap);
                }

                Castle crossedCastle = gameMap.getCrossedCastle(players[i].getActiveHero());
                if (!Objects.isNull(crossedCastle)) {
                    crossedCastle.enterCastle(players[i]);
                }

                players[i].AddGold(10);
            }
            turns--;
        }
    }
}