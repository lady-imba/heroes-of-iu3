package Building;

public class Building {
    private String name;
    private String description;
    private int cost;

    public Building(String name, String description, int cost) {
        this.name = name;
        this.description = description;
        this.cost = cost;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public int getCost() { return cost; }

    @Override
    public String toString() {
        return name + " - " + description;
    }
}