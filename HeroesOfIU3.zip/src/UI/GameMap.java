package UI;

import Battle.Battle;
import Castle.Castle;
import Hero.Hero;
import Oasis.Oasis;
import Player.Player;

import java.util.*;

public class GameMap {
    private int height;
    private int width;
    private Cell[][] map;
    private Cursor cursor;
    private Oasis oasis;
    private Castle[] castles;

    // implements - класс реализует методы объявленные в интерфейсе Comparable<>
    public static class Node implements Comparable<Node> {
        public int x;
        public int y;
        public int cost;

        public Node(int x, int y, int cost) {
            this.x = x;
            this.y = y;
            this.cost = cost;
        }

        @Override
        public int compareTo(Node other) {
            return Integer.compare(this.cost, other.cost);
        }
    }

    public void startBattle(Player player, Player computer) {
        Battle battle = new Battle(player, computer);
        battle.start();
    }

    public GameMap(int height, int width, Castle[] castles, Player player, Player computerPlayer) {
        this.height = height;
        this.width = width;
        this.map = new Cell[height][width];
        this.castles = castles;
        this.oasis = new Oasis(width/2-4,height/2+2);
        this.cursor = new Cursor(1,1, false,width,height);
        InitializeMap(player, computerPlayer);
    }

    private void InitializeMap(Player player, Player computerPlayer) {
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {

                if (i == j) {
                    this.map[i][j] = new Cell(Cell.road, i, j);
                } else {
                    if (i < 3 && j < 4) {
                        this.map[i][j] = new Cell(player.getTerrainSymbol(), i, j);
                    } else if (i > height - 4 && j > width - 5) {
                        this.map[i][j] = new Cell(computerPlayer.getTerrainSymbol(), i, j);
                    } else if (i == 3 && j < 5 || i < 4 && j == 4){
                        this.map[i][j] = new Cell(Cell.barrier, i, j);
                    } else if (i == height - 4 && j > width - 4 || i > height - 5 && j == width - 5){
                        this.map[i][j] = new Cell(Cell.barrier, i, j);
                    } else {
                        this.map[i][j] = new Cell(Cell.empty, i, j);
                    }
                }
            }
        }

        for (int i = 0; i < this.castles.length; i++) {
            int x = this.castles[i].getX();
            int y = this.castles[i].getY();

            if (i == 0) {
                this.map[y][x] = new Cell("И", x, y);
            } else {
                this.map[y][x] = new Cell("К", x, y);
            }
        }
        map[this.oasis.getOasisY()][this.oasis.getOasisX()] = new Cell(Cell.oasis, this.oasis.getOasisX(), this.oasis.getOasisY());
    }



    public void UpdateMapView(Player player, Player computerPlayer) {
        InitializeMap(player, computerPlayer);
    }

    // humanHero - активный герой человека.
    // anotherHeroes - активные герои ботов (по умолчанию массив из 1 элемента)
    public void Display (Hero humanHero, ArrayList<Hero> anotherHeroes, Player player, Player computerPlayer) {

        this.UpdateMapView(player, computerPlayer);

        this.map[humanHero.getY()][humanHero.getX()] = new Cell("Г", humanHero.getX(), humanHero.getY());

        for (int i = 0; i < anotherHeroes.size(); i++) {
            int x = anotherHeroes.get(i).getX();
            int y = anotherHeroes.get(i).getY();

            if (!Objects.equals(this.map[y][x].getType(), "Г")) {
                this.map[y][x].setType("" + i);
            }
        }

        if (this.cursor.isCursorActive()) {
            cursor.setTerrainUnderCursor(this.map[this.cursor.getCursorY()][this.cursor.getCursorX()].getType());
            this.map[this.cursor.getCursorY()][this.cursor.getCursorX()] =new Cell("+", this.cursor.getCursorX(), this.cursor.getCursorY()); ;
        }

        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                System.out.print(this.map[i][j].getSymbol() + " ");
            }
            System.out.println();
        }
    }

    public int calculatePathCost(int startX, int startY, int endX, int endY, Player player) {
        int[][] distances = new int[height][width]; // distances - хранит стоимость достижения каждой клетки
        //на каждой итерации переменная row получает одну строку этого массива (т.е. одномерный массив int[]).
        //.fill - заполняет все элементы массива row указанным значением
        for (int[] row : distances) Arrays.fill(row, Integer.MAX_VALUE);
        distances[startY][startX] = 0;//стартовая клетка получает стоимость 0

        //создаётся очередь с приоритетом для обработки клеток в порядке возрастания стоимости.
        PriorityQueue<Node> queue = new PriorityQueue<>();
        queue.add(new Node(startX, startY, 0));

        int[][] directions = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};

        while (!queue.isEmpty()) {
            Node current = queue.poll(); //из очереди извлекается клетка с наименьшей стоимостью
            if (current.x == endX && current.y == endY) return current.cost;
            if (current.cost > distances[current.y][current.x]) continue;

            //цикл по всем возможным направлениям движения
            for (int[] dir : directions) {
                //координаты соседней клетки
                int nx = current.x + dir[0];
                int ny = current.y + dir[1];

                // проверка границ карты
                // continue - пропуска текущей итерации и перехода к следующей
                if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;

                // Проверка диагональных препятствий
                // проверка является ли данное направление диагональным
                if (dir[0] != 0 && dir[1] != 0) {
                    //проверка проходимости двух ключевых клеток (справа/слева и сверху/снизу)
                    if (map[current.y][current.x + dir[0]].getMovementCost(player) == Integer.MAX_VALUE ||
                            map[current.y + dir[1]][current.x].getMovementCost(player) == Integer.MAX_VALUE) {
                        continue;
                    }
                }

                // Получаем текущую клетку
                Cell cell = map[ny][nx];

                // Если клетка содержит курсор (+), используем terrainUnderCursor
                if (cell.getType().equals("+")) {
                    cell = new Cell(cursor.getTerrainUnderCursor(), nx, ny);
                }

                int moveCost = cell.getMovementCost(player);//узнаем стоимость клетки
                if (moveCost == Integer.MAX_VALUE) continue;

                // диагональное движение дороже в 1.4 раза
                if (Math.abs(dir[0]) + Math.abs(dir[1]) == 2) {
                    //Math.ceil() - округляет результат вверх до целого числа.
                    moveCost = (int) Math.ceil(moveCost * 1.4);
                }

                int newCost = current.cost + moveCost;
                if (newCost < distances[ny][nx]) {
                    distances[ny][nx] = newCost;
                    queue.add(new Node(nx, ny, newCost));
                }
            }
        }
        return Integer.MAX_VALUE; // Путь не найден
    }

//    public ArrayList<Node> getReachableCells(int startX, int startY, int maxCost, Player player) {
//        int[][] distances = new int[height][width];
//        for (int[] row : distances) Arrays.fill(row, Integer.MAX_VALUE);
//        distances[startY][startX] = 0;
//
//        PriorityQueue<Node> queue = new PriorityQueue<>();
//        queue.add(new Node(startX, startY, 0));
//        ArrayList<Node> reachable = new ArrayList<>();
//
//        int[][] directions = {{0,1}, {1,0}, {0,-1}, {-1,0}, {1,1}, {1,-1}, {-1,1}, {-1,-1}};
//
//        while (!queue.isEmpty()) {
//            Node current = queue.poll();
//            if (current.cost > maxCost) continue;
//
//            if (distances[current.y][current.x] == current.cost) {
//                reachable.add(current);
//
//                for (int[] dir : directions) {
//                    int nx = current.x + dir[0];
//                    int ny = current.y + dir[1];
//
//                    if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;
//
//                    // Проверка диагональных препятствий
//                    if (dir[0] != 0 && dir[1] != 0) {
//                        if (map[current.y][current.x + dir[0]].getMovementCost(player) == Integer.MAX_VALUE ||
//                                map[current.y + dir[1]][current.x].getMovementCost(player) == Integer.MAX_VALUE) {
//                            continue;
//                        }
//                    }
//
//                    Cell cell = map[ny][nx];
//                    int moveCost = cell.getMovementCost(player);
//                    if (moveCost == Integer.MAX_VALUE) continue;
//
//                    if (Math.abs(dir[0]) + Math.abs(dir[1]) == 2) {
//                        moveCost = (int) Math.ceil(moveCost * 1.4);
//                    }
//
//                    int newCost = current.cost + moveCost;
//                    if (newCost <= maxCost && newCost < distances[ny][nx]) {
//                        distances[ny][nx] = newCost;
//                        queue.add(new Node(nx, ny, newCost));
//                    }
//                }
//            }
//        }
//        return reachable;
//    }

    public ArrayList<Node> getReachableCells(int startX, int startY, int maxCost, Player player) {
        int[][] distances = new int[height][width];
        for (int[] row : distances) Arrays.fill(row, Integer.MAX_VALUE);
        distances[startY][startX] = 0;

        PriorityQueue<Node> queue = new PriorityQueue<>();
        queue.add(new Node(startX, startY, 0));
        ArrayList<Node> reachable = new ArrayList<>();

        int[][] directions = {{0,1}, {1,0}, {0,-1}, {-1,0}, {1,1}, {1,-1}, {-1,1}, {-1,-1}};

        while (!queue.isEmpty()) {
            Node current = queue.poll();

            // Пропускаем если стоимость превышает лимит или клетка - барьер
            if (current.cost > maxCost ||
                    map[current.y][current.x].getMovementCost(player) == Integer.MAX_VALUE) {
                continue;
            }

            // Добавляем только если это новый оптимальный путь
            if (distances[current.y][current.x] == current.cost) {
                reachable.add(current);

                for (int[] dir : directions) {
                    int nx = current.x + dir[0];
                    int ny = current.y + dir[1];

                    // Проверка границ
                    if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;

                    // Проверка диагональных препятствий
                    if (dir[0] != 0 && dir[1] != 0) {
                        if (map[current.y][current.x + dir[0]].getMovementCost(player) == Integer.MAX_VALUE ||
                                map[current.y + dir[1]][current.x].getMovementCost(player) == Integer.MAX_VALUE) {
                            continue;
                        }
                    }

                    Cell cell = map[ny][nx];
                    int moveCost = cell.getMovementCost(player);
                    if (moveCost == Integer.MAX_VALUE) continue;

                    // Учет диагонального перемещения
                    if (Math.abs(dir[0]) + Math.abs(dir[1]) == 2) {
                        moveCost = (int) Math.ceil(moveCost * 1.4);
                    }

                    int newCost = current.cost + moveCost;
                    if (newCost <= maxCost && newCost < distances[ny][nx]) {
                        distances[ny][nx] = newCost;
                        queue.add(new Node(nx, ny, newCost));
                    }
                }
            }
        }

        // Фильтруем возможные дубликаты
        return new ArrayList<>(new HashSet<>(reachable));
    }


    public Castle getCrossedCastle(Hero hero) {
        for (Castle castle : this.castles) {
            if (castle.getX() == hero.getX() && castle.getY() == hero.getY()) {
                return castle;
            }
        }
        return null;
    }

    //добавила для тесттов
    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }

    public Cell[][] getMap() {
        return map;
    }

    public Castle[] getCastles() {
        return castles;
    }

    public Cursor getCursor() {
        return cursor;
    }

    public Oasis getOasis() {
        return oasis;
    }
}