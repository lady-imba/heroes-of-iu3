package Player;

import UI.GameMap;
import Hero.Hero;

import java.util.ArrayList;

public class HumanPlayer  extends Player {

    public HumanPlayer(Hero initialHero, String terrainSymbol, boolean isAnotherPlayer, String name) {
        super(initialHero, terrainSymbol, isAnotherPlayer, name);
    }
    //super — это вызов конструктора родительского класса (Player).

    public void moveHero(Hero hero, ArrayList<Hero> anotherHeroes, ComputerPlayer computer, GameMap map) {
        map.getCursor().setCursorActive(true);
        while (map.getCursor().isCursorActive()) {
            map.getCursor().selectCursorDirection();
            map.UpdateMapView(this, computer);
            map.Display(hero, anotherHeroes, this, computer);
            int pathCost = map.calculatePathCost(hero.getX(), hero.getY(), map.getCursor().getCursorX(), map.getCursor().getCursorY(), this);
            hero.displayRestMovementRange();
            if (pathCost <= hero.getMovementRange()) {
                System.out.println("Перемещение возможно. Стоимость: " + pathCost);
            } else {
                System.out.println("Перемещение невозможно! Выберите другую позицию.");
            }
        }

        int pathCost = map.calculatePathCost(hero.getX(), hero.getY(), map.getCursor().getCursorX(), map.getCursor().getCursorY(), this);
        if (pathCost <= hero.getMovementRange()) {
            hero.Move(map.getCursor().getCursorX(), map.getCursor().getCursorY(), pathCost);
            System.out.println("Герой перемещен на новую позицию.");

            if (map.getOasis().canUseOasis(hero)) {
                map.getOasis().applyOasisEffect(hero);
            }

            for (Hero otherHero : anotherHeroes) {
                if (hero.getX() == otherHero.getX() && hero.getY() == otherHero.getY()) {
                    System.out.println("Герой игрока и герой компьютера встретились!");
                    map.startBattle(this, computer);
                }
            }
        } else {
            System.out.println("Перемещение невозможно! Герой остается на месте.");
        }

        map.UpdateMapView(this, computer);
        map.Display(hero, anotherHeroes, this, computer);
    }
}
